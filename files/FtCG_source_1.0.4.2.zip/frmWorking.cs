﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.Text;
using System.Windows.Forms;

namespace ForTheCommonGood
{
    public partial class frmWorking: Form
    {
        public frmWorking(string text)
        {
            InitializeComponent();
            Text = Application.ProductName;
            label1.Text = text;
        }

        public void SetTaskText(string text)
        {
            label2.Text = text;
        }
    }
}
