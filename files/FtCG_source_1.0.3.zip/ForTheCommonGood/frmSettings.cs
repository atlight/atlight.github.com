﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace ForTheCommonGood
{
    public partial class frmSettings: Form
    {
        public frmSettings()
        {
            InitializeComponent();
            lblVersion.Text = "Version " + Application.ProductVersion;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Settings.LocalDomain = txtLocalDomain.Text;
            Settings.LocalUserName = txtLocalUserName.Text;
            Settings.LocalPassword = txtLocalPassword.Text;
            Settings.LocalSysop = chkLocalSysop.Checked;
            Settings.CommonsUserName = txtCommonsUserName.Text;
            Settings.CommonsPassword = txtCommonsPassword.Text;
            Settings.LogTransfers = chkLogTransfers.Checked;
            Settings.OpenBrowserAutomatically = chkOpenBrowserAutomatically.Checked;
            Settings.AutoUpdate = chkAutoUpdate.Checked;

            // save settings
            Settings.WriteSettings();

            DialogResult = DialogResult.OK;
            Close();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            if (Settings.LocalDomain != null)
                txtLocalDomain.Text = Settings.LocalDomain;
            if (Settings.LocalUserName != null)
                txtLocalUserName.Text = Settings.LocalUserName;
            if (Settings.LocalPassword != null)
                txtLocalPassword.Text = Settings.LocalPassword;
            chkLocalSysop.Checked = Settings.LocalSysop;
            if (Settings.CommonsUserName != null)
                txtCommonsUserName.Text = Settings.CommonsUserName;
            if (Settings.CommonsPassword != null)
                txtCommonsPassword.Text = Settings.CommonsPassword;
            chkLogTransfers.Checked = Settings.LogTransfers;
            chkOpenBrowserAutomatically.Checked = Settings.OpenBrowserAutomatically;
            chkAutoUpdate.Checked = Settings.AutoUpdate;
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                Process.Start("https://en.wikipedia.org/wiki/WP:FTCG");
            }
            catch (Exception)
            {
                MessageBox.Show("Can't open this link - you need to run FtCG locally, not in a Partial Trust scenario.");
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                Process.Start("https://en.wikipedia.org/wiki/User_talk:This,_that_and_the_other");
            }
            catch (Exception)
            {
                MessageBox.Show("Can't open this link - you need to run FtCG locally, not in a Partial Trust scenario.");
            }
        }
    }

    internal static class Settings
    {
        public static string LocalDomain { get; set; }
        public static string LocalUserName { get; set; }
        public static string LocalPassword { get; set; }
        public static bool LocalSysop { get; set; }
        public static string CommonsUserName { get; set; }
        public static string CommonsPassword { get; set; }
        public static bool LogTransfers { get; set; }
        public static bool OpenBrowserAutomatically { get; set; }
        public static bool AutoUpdate { get; set; }

        public static string CurrentSourceOption { get; set; }
        public static string SourceCategory { get; set; }
        public static string SourceTextFile { get; set; }

        const string settingsFileName = "ForTheCommonGood.cfg";

        static Settings()
        {
            LocalDomain = "en.wikipedia";
            LocalUserName = LocalPassword = CommonsPassword = CommonsUserName =
                CurrentSourceOption = SourceCategory = SourceTextFile = "";
            LocalSysop = LogTransfers = OpenBrowserAutomatically = false;
            AutoUpdate = true;
        }

        public static void ReadSettings()
        {
            try
            {
                foreach (string l in File.ReadAllLines(settingsFileName, Encoding.UTF8))
                {
                    if (l.StartsWith("LocalDomain="))
                        Settings.LocalDomain = l.Substring("LocalDomain=".Length);
                    if (l.StartsWith("LocalUserName="))
                        Settings.LocalUserName = l.Substring("LocalUserName=".Length);
                    if (l.StartsWith("LocalPassword="))
                        Settings.LocalPassword = Encoding.UTF8.GetString(Convert.FromBase64String(l.Substring("LocalPassword=".Length)));
                    if (l.StartsWith("LocalSysop="))
                        Settings.LocalSysop = l.Substring("LocalSysop=".Length) == "true";
                    if (l.StartsWith("CommonsUserName="))
                        Settings.CommonsUserName = l.Substring("CommonsUserName=".Length);
                    if (l.StartsWith("CommonsPassword="))
                        Settings.CommonsPassword = Encoding.UTF8.GetString(Convert.FromBase64String(l.Substring("CommonsPassword=".Length)));
                    if (l.StartsWith("LogTransfers="))
                        Settings.LogTransfers = l.Substring("LogTransfers=".Length) == "true";
                    if (l.StartsWith("OpenBrowserAutomatically="))
                        Settings.OpenBrowserAutomatically = l.Substring("OpenBrowserAutomatically=".Length) == "true";
                    if (l.StartsWith("AutoUpdate="))
                        Settings.AutoUpdate = l.Substring("AutoUpdate=".Length) != "false";
                    if (l.StartsWith("CurrentSourceOption="))
                        Settings.CurrentSourceOption = l.Substring("CurrentSourceOption=".Length);
                    if (l.StartsWith("SourceCategory="))
                        Settings.SourceCategory = l.Substring("SourceCategory=".Length);
                    if (l.StartsWith("SourceTextFile="))
                        Settings.SourceTextFile = l.Substring("SourceTextFile=".Length);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred when trying to read the settings file.\n\n" + ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        public static void WriteSettings()
        {
            try
            {
                File.WriteAllLines(settingsFileName, new string[] {
                    "LocalDomain=" + Settings.LocalDomain,
                    "LocalUserName=" + Settings.LocalUserName,
                    "LocalPassword=" + Convert.ToBase64String(Encoding.UTF8.GetBytes(Settings.LocalPassword)),
                    "LocalSysop=" + (Settings.LocalSysop ? "true" : "false"),
                    "CommonsUserName=" + Settings.CommonsUserName,
                    "CommonsPassword=" + Convert.ToBase64String(Encoding.UTF8.GetBytes(Settings.CommonsPassword)),
                    "LogTransfers=" + (Settings.LogTransfers ? "true" : "false"),
                    "OpenBrowserAutomatically=" + (Settings.OpenBrowserAutomatically ? "true" : "false"),
                    "AutoUpdate=" + (Settings.AutoUpdate ? "true" : "false"),
                    "CurrentSourceOption=" + Settings.CurrentSourceOption,
                    "SourceCategory=" + Settings.SourceCategory,
                    "SourceTextFile=" + Settings.SourceTextFile,
                }, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred when trying to save the settings file.\n\n" + ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
    }
}
