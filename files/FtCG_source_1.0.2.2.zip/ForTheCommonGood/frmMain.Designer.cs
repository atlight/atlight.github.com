﻿namespace ForTheCommonGood
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNormName = new System.Windows.Forms.TextBox();
            this.btnSettings = new System.Windows.Forms.Button();
            this.chkIgnoreWarnings = new System.Windows.Forms.CheckBox();
            this.lnkLocalFile = new System.Windows.Forms.LinkLabel();
            this.lnkCommonsFile = new System.Windows.Forms.LinkLabel();
            this.button4 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chkDeleteAfter = new System.Windows.Forms.CheckBox();
            this.optCopy = new System.Windows.Forms.RadioButton();
            this.optCopyBot = new System.Windows.Forms.RadioButton();
            this.button3 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblRevision = new System.Windows.Forms.Label();
            this.lblDimensions = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblPastRevisions = new System.Windows.Forms.Label();
            this.btnPastRevisions = new System.Windows.Forms.Button();
            this.panWarning = new System.Windows.Forms.Panel();
            this.lblWarningText = new System.Windows.Forms.Label();
            this.icoWarning = new System.Windows.Forms.PictureBox();
            this.lblWarningHeading = new System.Windows.Forms.Label();
            this.optOther = new System.Windows.Forms.RadioButton();
            this.panRoot = new System.Windows.Forms.Panel();
            this.panFileLinks = new System.Windows.Forms.Panel();
            this.lblFileLinks = new System.Windows.Forms.Label();
            this.lnkGoToFileLink = new System.Windows.Forms.LinkLabel();
            this.lstFileLinks = new System.Windows.Forms.ListBox();
            this.optCopyPriority = new System.Windows.Forms.RadioButton();
            this.btnViewExif = new System.Windows.Forms.Button();
            this.lblViewExif = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panStatus = new System.Windows.Forms.Panel();
            this.lblStatusTask = new System.Windows.Forms.Label();
            this.icoInfo = new System.Windows.Forms.PictureBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lnkLinkify = new System.Windows.Forms.LinkLabel();
            this.lnkGoogleImageSearch = new System.Windows.Forms.LinkLabel();
            this.tableLayoutPanel1.SuspendLayout();
            this.panWarning.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize) (this.icoWarning)).BeginInit();
            this.panRoot.SuspendLayout();
            this.panFileLinks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize) (this.pictureBox1)).BeginInit();
            this.panStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize) (this.icoInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "&Name:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(56, 17);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(224, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(288, 17);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "&Go";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox2.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.textBox2.Location = new System.Drawing.Point(3, 16);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox2.Size = new System.Drawing.Size(466, 224);
            this.textBox2.TabIndex = 1;
            this.textBox2.WordWrap = false;
            // 
            // textBox3
            // 
            this.textBox3.AcceptsReturn = true;
            this.textBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox3.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.textBox3.Location = new System.Drawing.Point(475, 16);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox3.Size = new System.Drawing.Size(466, 224);
            this.textBox3.TabIndex = 3;
            this.textBox3.WordWrap = false;
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.Location = new System.Drawing.Point(848, 395);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(104, 23);
            this.button2.TabIndex = 26;
            this.button2.Text = "&Transfer";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.DoTransfer);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(320, 499);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(286, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Note: this preview does not take into account EXIF rotation";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles) ((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBox2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox3, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label8, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(8, 56);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(944, 243);
            this.tableLayoutPanel1.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(206, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "File description page on English Wiki&pedia";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(475, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(220, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "File description page on Wi&kimedia Commons";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(688, 307);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(216, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "New &filename on Commons (with File: prefix):";
            // 
            // txtNormName
            // 
            this.txtNormName.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNormName.Location = new System.Drawing.Point(688, 323);
            this.txtNormName.Name = "txtNormName";
            this.txtNormName.Size = new System.Drawing.Size(264, 20);
            this.txtNormName.TabIndex = 23;
            // 
            // btnSettings
            // 
            this.btnSettings.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSettings.Location = new System.Drawing.Point(880, 8);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(72, 23);
            this.btnSettings.TabIndex = 32;
            this.btnSettings.Text = "&Settings...";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // chkIgnoreWarnings
            // 
            this.chkIgnoreWarnings.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.chkIgnoreWarnings.Location = new System.Drawing.Point(704, 347);
            this.chkIgnoreWarnings.Name = "chkIgnoreWarnings";
            this.chkIgnoreWarnings.Size = new System.Drawing.Size(248, 24);
            this.chkIgnoreWarnings.TabIndex = 24;
            this.chkIgnoreWarnings.Text = "Ignore &warnings";
            this.chkIgnoreWarnings.UseVisualStyleBackColor = true;
            // 
            // lnkLocalFile
            // 
            this.lnkLocalFile.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lnkLocalFile.AutoSize = true;
            this.lnkLocalFile.Enabled = false;
            this.lnkLocalFile.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkLocalFile.Location = new System.Drawing.Point(688, 423);
            this.lnkLocalFile.Name = "lnkLocalFile";
            this.lnkLocalFile.Size = new System.Drawing.Size(175, 13);
            this.lnkLocalFile.TabIndex = 27;
            this.lnkLocalFile.TabStop = true;
            this.lnkLocalFile.Text = "View file page on &English Wikipedia";
            this.lnkLocalFile.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkLocalFile_LinkClicked);
            // 
            // lnkCommonsFile
            // 
            this.lnkCommonsFile.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lnkCommonsFile.AutoSize = true;
            this.lnkCommonsFile.Enabled = false;
            this.lnkCommonsFile.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkCommonsFile.Location = new System.Drawing.Point(688, 443);
            this.lnkCommonsFile.Name = "lnkCommonsFile";
            this.lnkCommonsFile.Size = new System.Drawing.Size(189, 13);
            this.lnkCommonsFile.TabIndex = 28;
            this.lnkCommonsFile.TabStop = true;
            this.lnkCommonsFile.Text = "View file page on Wikimedia &Commons\r\n";
            this.lnkCommonsFile.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkCommonsFile_LinkClicked);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(376, 17);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(104, 23);
            this.button4.TabIndex = 4;
            this.button4.Text = "&Random file";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.RandomImage);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(369, 8);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1, 40);
            this.panel1.TabIndex = 3;
            // 
            // chkDeleteAfter
            // 
            this.chkDeleteAfter.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.chkDeleteAfter.Checked = true;
            this.chkDeleteAfter.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDeleteAfter.Location = new System.Drawing.Point(704, 371);
            this.chkDeleteAfter.Name = "chkDeleteAfter";
            this.chkDeleteAfter.Size = new System.Drawing.Size(248, 24);
            this.chkDeleteAfter.TabIndex = 25;
            this.chkDeleteAfter.Text = "Tag/delete &after transfer";
            this.chkDeleteAfter.UseVisualStyleBackColor = true;
            // 
            // optCopy
            // 
            this.optCopy.AutoSize = true;
            this.optCopy.Location = new System.Drawing.Point(488, 4);
            this.optCopy.Name = "optCopy";
            this.optCopy.Size = new System.Drawing.Size(207, 17);
            this.optCopy.TabIndex = 5;
            this.optCopy.Text = "Category:Copy to Wikimedia Commons";
            this.optCopy.UseVisualStyleBackColor = true;
            this.optCopy.CheckedChanged += new System.EventHandler(this.optCopyFoo_CheckedChanged);
            // 
            // optCopyBot
            // 
            this.optCopyBot.AutoSize = true;
            this.optCopyBot.Location = new System.Drawing.Point(488, 20);
            this.optCopyBot.Name = "optCopyBot";
            this.optCopyBot.Size = new System.Drawing.Size(278, 17);
            this.optCopyBot.TabIndex = 6;
            this.optCopyBot.Text = "Category:Copy to Wikimedia Commons (bot-assessed)";
            this.optCopyBot.UseVisualStyleBackColor = true;
            this.optCopyBot.CheckedChanged += new System.EventHandler(this.optCopyFoo_CheckedChanged);
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.Location = new System.Drawing.Point(848, 491);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(104, 23);
            this.button3.TabIndex = 31;
            this.button3.Text = "&Decline transfer";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.DeclineTransfer);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(726, 496);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 13);
            this.label4.TabIndex = 30;
            this.label4.Text = "If the file is not eligible:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblName
            // 
            this.lblName.Anchor = ((System.Windows.Forms.AnchorStyles) (((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblName.AutoEllipsis = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lblName.Location = new System.Drawing.Point(320, 307);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(352, 13);
            this.lblName.TabIndex = 10;
            // 
            // lblRevision
            // 
            this.lblRevision.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblRevision.Location = new System.Drawing.Point(320, 325);
            this.lblRevision.Name = "lblRevision";
            this.lblRevision.Size = new System.Drawing.Size(232, 13);
            this.lblRevision.TabIndex = 11;
            // 
            // lblDimensions
            // 
            this.lblDimensions.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDimensions.Location = new System.Drawing.Point(320, 343);
            this.lblDimensions.Name = "lblDimensions";
            this.lblDimensions.Size = new System.Drawing.Size(232, 13);
            this.lblDimensions.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int) (((byte) (192)))), ((int) (((byte) (64)))), ((int) (((byte) (64)))));
            this.label5.Location = new System.Drawing.Point(688, 461);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(264, 32);
            this.label5.TabIndex = 29;
            this.label5.Text = "Don\'t forget to add categories!\r\n(Click the link above and use HotCat if you pref" +
                "er.)";
            // 
            // lblPastRevisions
            // 
            this.lblPastRevisions.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblPastRevisions.Location = new System.Drawing.Point(560, 325);
            this.lblPastRevisions.Name = "lblPastRevisions";
            this.lblPastRevisions.Size = new System.Drawing.Size(104, 13);
            this.lblPastRevisions.TabIndex = 15;
            this.lblPastRevisions.Text = "2 earlier versions";
            this.lblPastRevisions.Visible = false;
            // 
            // btnPastRevisions
            // 
            this.btnPastRevisions.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPastRevisions.Location = new System.Drawing.Point(560, 340);
            this.btnPastRevisions.Name = "btnPastRevisions";
            this.btnPastRevisions.Size = new System.Drawing.Size(104, 23);
            this.btnPastRevisions.TabIndex = 16;
            this.btnPastRevisions.Text = "Select &version...";
            this.btnPastRevisions.UseVisualStyleBackColor = true;
            this.btnPastRevisions.Visible = false;
            this.btnPastRevisions.Click += new System.EventHandler(this.SelectVersion);
            // 
            // panWarning
            // 
            this.panWarning.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panWarning.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (255)))), ((int) (((byte) (238)))), ((int) (((byte) (238)))));
            this.panWarning.Controls.Add(this.lblWarningText);
            this.panWarning.Controls.Add(this.icoWarning);
            this.panWarning.Controls.Add(this.lblWarningHeading);
            this.panWarning.Location = new System.Drawing.Point(320, 367);
            this.panWarning.Name = "panWarning";
            this.panWarning.Size = new System.Drawing.Size(232, 126);
            this.panWarning.TabIndex = 13;
            this.panWarning.Visible = false;
            this.panWarning.Paint += new System.Windows.Forms.PaintEventHandler(this.FmboxLookalike);
            // 
            // lblWarningText
            // 
            this.lblWarningText.Location = new System.Drawing.Point(6, 45);
            this.lblWarningText.Margin = new System.Windows.Forms.Padding(0);
            this.lblWarningText.Name = "lblWarningText";
            this.lblWarningText.Size = new System.Drawing.Size(219, 74);
            this.lblWarningText.TabIndex = 1;
            // 
            // icoWarning
            // 
            this.icoWarning.Image = global::ForTheCommonGood.Properties.Resources.Imbox_content;
            this.icoWarning.Location = new System.Drawing.Point(8, 6);
            this.icoWarning.Name = "icoWarning";
            this.icoWarning.Size = new System.Drawing.Size(32, 32);
            this.icoWarning.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.icoWarning.TabIndex = 1;
            this.icoWarning.TabStop = false;
            // 
            // lblWarningHeading
            // 
            this.lblWarningHeading.AutoSize = true;
            this.lblWarningHeading.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lblWarningHeading.ForeColor = System.Drawing.Color.Firebrick;
            this.lblWarningHeading.Location = new System.Drawing.Point(42, 13);
            this.lblWarningHeading.Name = "lblWarningHeading";
            this.lblWarningHeading.Size = new System.Drawing.Size(53, 16);
            this.lblWarningHeading.TabIndex = 0;
            this.lblWarningHeading.Text = "Notice";
            // 
            // optOther
            // 
            this.optOther.AutoSize = true;
            this.optOther.Location = new System.Drawing.Point(720, 4);
            this.optOther.Name = "optOther";
            this.optOther.Size = new System.Drawing.Size(95, 17);
            this.optOther.TabIndex = 8;
            this.optOther.Text = "&Other source...";
            this.optOther.UseVisualStyleBackColor = true;
            this.optOther.Click += new System.EventHandler(this.optOther_CheckedChanged);
            this.optOther.CheckedChanged += new System.EventHandler(this.optCopyFoo_CheckedChanged);
            // 
            // panRoot
            // 
            this.panRoot.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.panRoot.Controls.Add(this.lnkGoogleImageSearch);
            this.panRoot.Controls.Add(this.lnkLinkify);
            this.panRoot.Controls.Add(this.label2);
            this.panRoot.Controls.Add(this.panFileLinks);
            this.panRoot.Controls.Add(this.optCopyPriority);
            this.panRoot.Controls.Add(this.optOther);
            this.panRoot.Controls.Add(this.label1);
            this.panRoot.Controls.Add(this.panWarning);
            this.panRoot.Controls.Add(this.textBox1);
            this.panRoot.Controls.Add(this.btnViewExif);
            this.panRoot.Controls.Add(this.btnPastRevisions);
            this.panRoot.Controls.Add(this.button1);
            this.panRoot.Controls.Add(this.lblViewExif);
            this.panRoot.Controls.Add(this.lblPastRevisions);
            this.panRoot.Controls.Add(this.pictureBox1);
            this.panRoot.Controls.Add(this.label4);
            this.panRoot.Controls.Add(this.button2);
            this.panRoot.Controls.Add(this.button3);
            this.panRoot.Controls.Add(this.label5);
            this.panRoot.Controls.Add(this.tableLayoutPanel1);
            this.panRoot.Controls.Add(this.lblDimensions);
            this.panRoot.Controls.Add(this.label3);
            this.panRoot.Controls.Add(this.lblRevision);
            this.panRoot.Controls.Add(this.txtNormName);
            this.panRoot.Controls.Add(this.lblName);
            this.panRoot.Controls.Add(this.btnSettings);
            this.panRoot.Controls.Add(this.optCopyBot);
            this.panRoot.Controls.Add(this.chkIgnoreWarnings);
            this.panRoot.Controls.Add(this.optCopy);
            this.panRoot.Controls.Add(this.chkDeleteAfter);
            this.panRoot.Controls.Add(this.panel2);
            this.panRoot.Controls.Add(this.panel1);
            this.panRoot.Controls.Add(this.lnkLocalFile);
            this.panRoot.Controls.Add(this.button4);
            this.panRoot.Controls.Add(this.lnkCommonsFile);
            this.panRoot.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panRoot.Location = new System.Drawing.Point(0, 0);
            this.panRoot.Name = "panRoot";
            this.panRoot.Size = new System.Drawing.Size(961, 522);
            this.panRoot.TabIndex = 0;
            // 
            // panFileLinks
            // 
            this.panFileLinks.Anchor = ((System.Windows.Forms.AnchorStyles) (((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panFileLinks.Controls.Add(this.lblFileLinks);
            this.panFileLinks.Controls.Add(this.lnkGoToFileLink);
            this.panFileLinks.Controls.Add(this.lstFileLinks);
            this.panFileLinks.Location = new System.Drawing.Point(560, 408);
            this.panFileLinks.MaximumSize = new System.Drawing.Size(240, 1000);
            this.panFileLinks.Name = "panFileLinks";
            this.panFileLinks.Size = new System.Drawing.Size(104, 108);
            this.panFileLinks.TabIndex = 34;
            // 
            // lblFileLinks
            // 
            this.lblFileLinks.Anchor = ((System.Windows.Forms.AnchorStyles) (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFileLinks.Location = new System.Drawing.Point(0, 0);
            this.lblFileLinks.Name = "lblFileLinks";
            this.lblFileLinks.Size = new System.Drawing.Size(108, 16);
            this.lblFileLinks.TabIndex = 19;
            this.lblFileLinks.Text = "Pages using this file:";
            // 
            // lnkGoToFileLink
            // 
            this.lnkGoToFileLink.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lnkGoToFileLink.Enabled = false;
            this.lnkGoToFileLink.Location = new System.Drawing.Point(57, 88);
            this.lnkGoToFileLink.Name = "lnkGoToFileLink";
            this.lnkGoToFileLink.Size = new System.Drawing.Size(47, 15);
            this.lnkGoToFileLink.TabIndex = 33;
            this.lnkGoToFileLink.TabStop = true;
            this.lnkGoToFileLink.Text = "Go →";
            this.lnkGoToFileLink.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.lnkGoToFileLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkGoToFileLink_LinkClicked);
            // 
            // lstFileLinks
            // 
            this.lstFileLinks.Anchor = ((System.Windows.Forms.AnchorStyles) (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstFileLinks.Items.AddRange(new object[] {
            " "});
            this.lstFileLinks.Location = new System.Drawing.Point(0, 16);
            this.lstFileLinks.Name = "lstFileLinks";
            this.lstFileLinks.Size = new System.Drawing.Size(104, 69);
            this.lstFileLinks.TabIndex = 20;
            this.lstFileLinks.SelectedIndexChanged += new System.EventHandler(this.lstFileLinks_SelectedIndexChanged);
            this.lstFileLinks.ForeColorChanged += new System.EventHandler(this.lstFileLinks_SelectedIndexChanged);
            // 
            // optCopyPriority
            // 
            this.optCopyPriority.AutoSize = true;
            this.optCopyPriority.Checked = true;
            this.optCopyPriority.Location = new System.Drawing.Point(488, 36);
            this.optCopyPriority.Name = "optCopyPriority";
            this.optCopyPriority.Size = new System.Drawing.Size(248, 17);
            this.optCopyPriority.TabIndex = 7;
            this.optCopyPriority.TabStop = true;
            this.optCopyPriority.Text = "Category:Move to Commons Priority Candidates";
            this.optCopyPriority.UseVisualStyleBackColor = true;
            // 
            // btnViewExif
            // 
            this.btnViewExif.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnViewExif.Location = new System.Drawing.Point(560, 382);
            this.btnViewExif.Name = "btnViewExif";
            this.btnViewExif.Size = new System.Drawing.Size(104, 23);
            this.btnViewExif.TabIndex = 18;
            this.btnViewExif.Text = "View &metadata";
            this.btnViewExif.UseVisualStyleBackColor = true;
            this.btnViewExif.Visible = false;
            this.btnViewExif.Click += new System.EventHandler(this.ViewExifData);
            // 
            // lblViewExif
            // 
            this.lblViewExif.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblViewExif.AutoSize = true;
            this.lblViewExif.Location = new System.Drawing.Point(560, 367);
            this.lblViewExif.Name = "lblViewExif";
            this.lblViewExif.Size = new System.Drawing.Size(98, 13);
            this.lblViewExif.TabIndex = 17;
            this.lblViewExif.Text = "Contains EXIF data";
            this.lblViewExif.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox1.BackgroundImage = global::ForTheCommonGood.Properties.Resources.Checker_16x16;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.InitialImage = ((System.Drawing.Image) (resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(8, 307);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(304, 208);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(680, 308);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1, 204);
            this.panel2.TabIndex = 21;
            // 
            // panStatus
            // 
            this.panStatus.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (251)))), ((int) (((byte) (251)))), ((int) (((byte) (251)))));
            this.panStatus.Controls.Add(this.lblStatusTask);
            this.panStatus.Controls.Add(this.icoInfo);
            this.panStatus.Controls.Add(this.lblStatus);
            this.panStatus.Location = new System.Drawing.Point(368, 232);
            this.panStatus.Name = "panStatus";
            this.panStatus.Size = new System.Drawing.Size(200, 54);
            this.panStatus.TabIndex = 1;
            this.panStatus.Visible = false;
            this.panStatus.Paint += new System.Windows.Forms.PaintEventHandler(this.FmboxLookalike);
            // 
            // lblStatusTask
            // 
            this.lblStatusTask.AutoSize = true;
            this.lblStatusTask.Location = new System.Drawing.Point(69, 31);
            this.lblStatusTask.Name = "lblStatusTask";
            this.lblStatusTask.Size = new System.Drawing.Size(0, 13);
            this.lblStatusTask.TabIndex = 1;
            // 
            // icoInfo
            // 
            this.icoInfo.Image = global::ForTheCommonGood.Properties.Resources.Ambox_notice;
            this.icoInfo.Location = new System.Drawing.Point(17, 7);
            this.icoInfo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.icoInfo.Name = "icoInfo";
            this.icoInfo.Size = new System.Drawing.Size(40, 40);
            this.icoInfo.TabIndex = 4;
            this.icoInfo.TabStop = false;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lblStatus.Location = new System.Drawing.Point(69, 10);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(76, 16);
            this.lblStatus.TabIndex = 0;
            this.lblStatus.Text = "Loading...";
            // 
            // lnkLinkify
            // 
            this.lnkLinkify.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lnkLinkify.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkLinkify.Location = new System.Drawing.Point(824, 55);
            this.lnkLinkify.Name = "lnkLinkify";
            this.lnkLinkify.Size = new System.Drawing.Size(128, 14);
            this.lnkLinkify.TabIndex = 35;
            this.lnkLinkify.TabStop = true;
            this.lnkLinkify.Text = "Linkify selected text";
            this.lnkLinkify.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.lnkLinkify.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkLinkify_LinkClicked);
            // 
            // lnkGoogleImageSearch
            // 
            this.lnkGoogleImageSearch.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lnkGoogleImageSearch.AutoSize = true;
            this.lnkGoogleImageSearch.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkGoogleImageSearch.Location = new System.Drawing.Point(884, 432);
            this.lnkGoogleImageSearch.Name = "lnkGoogleImageSearch";
            this.lnkGoogleImageSearch.Size = new System.Drawing.Size(74, 13);
            this.lnkGoogleImageSearch.TabIndex = 36;
            this.lnkGoogleImageSearch.TabStop = true;
            this.lnkGoogleImageSearch.Text = "Google check";
            this.lnkGoogleImageSearch.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkGoogleImageSearch_LinkClicked);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(961, 522);
            this.Controls.Add(this.panStatus);
            this.Controls.Add(this.panRoot);
            this.MinimumSize = new System.Drawing.Size(977, 560);
            this.Name = "frmMain";
            this.Text = "For the Common Good";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMain_FormClosed);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Resize += new System.EventHandler(this.frmMain_Resize);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panWarning.ResumeLayout(false);
            this.panWarning.PerformLayout();
            ((System.ComponentModel.ISupportInitialize) (this.icoWarning)).EndInit();
            this.panRoot.ResumeLayout(false);
            this.panRoot.PerformLayout();
            this.panFileLinks.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize) (this.pictureBox1)).EndInit();
            this.panStatus.ResumeLayout(false);
            this.panStatus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize) (this.icoInfo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNormName;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.CheckBox chkIgnoreWarnings;
        private System.Windows.Forms.LinkLabel lnkLocalFile;
        private System.Windows.Forms.LinkLabel lnkCommonsFile;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox chkDeleteAfter;
        private System.Windows.Forms.RadioButton optCopy;
        private System.Windows.Forms.RadioButton optCopyBot;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblRevision;
        private System.Windows.Forms.Label lblDimensions;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblPastRevisions;
        private System.Windows.Forms.Button btnPastRevisions;
        private System.Windows.Forms.Panel panWarning;
        private System.Windows.Forms.PictureBox icoWarning;
        private System.Windows.Forms.Label lblWarningHeading;
        private System.Windows.Forms.Label lblWarningText;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton optOther;
        private System.Windows.Forms.Panel panRoot;
        private System.Windows.Forms.Panel panStatus;
        private System.Windows.Forms.Label lblStatusTask;
        private System.Windows.Forms.PictureBox icoInfo;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.RadioButton optCopyPriority;
        private System.Windows.Forms.Button btnViewExif;
        private System.Windows.Forms.Label lblViewExif;
        private System.Windows.Forms.ListBox lstFileLinks;
        private System.Windows.Forms.Label lblFileLinks;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.LinkLabel lnkGoToFileLink;
        private System.Windows.Forms.Panel panFileLinks;
        private System.Windows.Forms.LinkLabel lnkLinkify;
        private System.Windows.Forms.LinkLabel lnkGoogleImageSearch;
    }
}

