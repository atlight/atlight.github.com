﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ForTheCommonGood
{
    public partial class frmRandomSource: Form
    {
        public frmRandomSource()
        {
            InitializeComponent();
            CheckChange(null, null);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog(this) == DialogResult.Cancel)
                return;
            txtFileName.Text = openFileDialog1.FileName;
        }

        private void CheckChange(object sender, EventArgs e)
        {
            txtCategory.Enabled = optCategory.Checked;
            txtFileName.Enabled = button3.Enabled = optTextFile.Checked;
        }

        private void frmRandomSource_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (optTextFile.Checked && DialogResult == DialogResult.OK && !File.Exists(txtFileName.Text) &&
                MessageBox.Show("The file \"" + txtFileName.Text + "\" could not be found. Continue anyway?",
                Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                e.Cancel = true;
        }
    }
}
