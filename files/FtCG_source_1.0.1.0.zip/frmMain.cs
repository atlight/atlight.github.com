﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Xml;
using System.Collections.Specialized;
using System.Collections;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Globalization;

namespace ForTheCommonGood
{
    public partial class frmMain: Form
    {
        byte[] ImageData;

        enum FileSources
        {
            ManualInput,
            Category,
            TextFile
        }
        FileSources CurrentFileSource;
        FileSources RandomFileSource;
        string SourceTag;  // category name or name of text file

        List<string> TextFileCache = new List<string>();
        int RandomCurrentIndex;

        frmWorking StatusBox;

        Regex CopyToCommonsRegex = new Regex("{{(mtc|(copy |move )?to ?commons|move to wikimedia commons|copy to wikimedia commons)[^}]*}}\n?", RegexOptions.IgnoreCase);

        public frmMain()
        {
            InitializeComponent();

            icoWarning.Image = SystemIcons.Warning.ToBitmap();

            // time to load settings
            if (File.Exists("ForTheCommonGood.cfg"))
            {
                Settings.ReadSettings();
            }
            else
            {
                MessageBox.Show("Welcome to For the Common Good.\n\nThe next dialog will ask for your wiki login credentials and save them to disk. You will not need to enter them every time.\n\nYour wiki password will be stored on disk - not in cleartext, but in the Base64 encoding (no security at all!). Be aware of this.",
                    Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnSettings_Click(this, EventArgs.Empty);
            }

            InitSettings();
        }

        void ErrorHandler(String msg)
        {
            MessageBox.Show(msg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            EnableForm(true);
        }

        string FormatTimestamp(XmlNode n)
        {
            return DateTime.Parse(n.Attributes["timestamp"].Value).ToUniversalTime().ToString("HH:mm, d MMMM yyyy", DateTimeFormatInfo.InvariantInfo);
        }

        string FormatDimensions(XmlNode n)
        {
            if (n.Attributes["width"].Value == "0")
                return n.Attributes["size"].Value + " bytes";  // not formatted, since it may be some weird format .NET doesn't know about
            else
                return int.Parse(n.Attributes["width"].Value).ToString("n0", CultureInfo.InvariantCulture) + " × " +
                    int.Parse(n.Attributes["height"].Value).ToString("n0", CultureInfo.InvariantCulture) + " (" +
                    int.Parse(n.Attributes["size"].Value).ToString("n0", CultureInfo.InvariantCulture) + " bytes)";
        }

        void ToggleWarningBox(bool show)
        {
            panWarning.Visible = show;
            BackColor = show ? Color.FromArgb(246, 255, 192) : DefaultBackColor;
        }

        void EnableForm(bool enabled)
        {
            Invoke(new Action(delegate()
            {
                //button1.Enabled = button2.Enabled = button3.Enabled = button4.Enabled =
                //    btnPastRevisions.Enabled = btnSettings.Enabled = textBox1.Enabled =
                //    textBox2.Enabled = textBox3.Enabled = chkDeleteAfter.Enabled =
                //    chkIgnoreWarnings.Enabled = optCopy.Enabled = optCopyBot.Enabled =
                //    optOther.Enabled = enabled;
                panRoot.Enabled = enabled;
                if (!enabled)
                    lnkCommonsFile.Enabled = lnkLocalFile.Enabled = false;
            }));
        }

        string filename;  // the old enwiki filename
        XmlNodeList iis;

        private void button1_Click(object sender, EventArgs e)
        {
            CurrentFileSource = FileSources.ManualInput;
            try
            {
                DownloadAndProcess();
            }
            finally
            {
                EnableForm(true);
            }
        }

        void DownloadAndProcess()
        {
            Invoke(new Action(delegate()
            {
                textBox2.Text = textBox3.Text = lblName.Text = lblRevision.Text = lblDimensions.Text = "";
                pictureBox1.Image = null;
                lblPastRevisions.Visible = btnPastRevisions.Visible = false;
                chkIgnoreWarnings.Checked = false;
                ToggleWarningBox(false);

                textBox1.Text = textBox1.Text.Trim();
            }));
            if (cl != null)
                cl.CancelAsync();

            filename = "File:" + Regex.Replace(textBox1.Text, "^(Image|File):", "", RegexOptions.IgnoreCase);

            EnableForm(false);

            iis = null;
            ImageData = null;
            string text = "";
            MorebitsDotNet.ActionCompleted sentry = new MorebitsDotNet.ActionCompleted(2);
            sentry.Done += new Action(delegate()
            {
                // identify potential problems
                List<string> potentialProblems = new List<string>();
                if (Regex.IsMatch(text, "{{(db-)?now ?commons", RegexOptions.IgnoreCase))
                {
                    potentialProblems.Add("• The file is tagged with {{now Commons}}, so it has probably already been transferred.");
                    if (CurrentFileSource == FileSources.Category)
                    {
                        RandomBlacklist.Add(RandomCurrentIndex);  // don't turn up this file again
                        RandomImage(null, null);
                        return;
                    }
                }
                if (Regex.IsMatch(text, "{{db-", RegexOptions.IgnoreCase))
                    potentialProblems.Add("• The file appears to be tagged for speedy deletion.");
                if (Regex.IsMatch(text, "{{puf", RegexOptions.IgnoreCase))
                    potentialProblems.Add("• The file appears to be listed at PUF (Possibly unfree files). Check the discussion before transferring.");
                if (Regex.IsMatch(text, "{{ffd", RegexOptions.IgnoreCase))
                    potentialProblems.Add("• The file appears to be nominated for deletion. Check the deletion discussion at FFD before transferring.");
                if (Regex.IsMatch(text, "{{non-free", RegexOptions.IgnoreCase))
                    potentialProblems.Add("• The file appears to be non-free. Commons cannot accept non-free files.");
                if (Regex.IsMatch(text, "{{do not (copy|move) to commons", RegexOptions.IgnoreCase))
                    potentialProblems.Add("• The file is tagged with {{do not move to Commons}}.");
                if (Regex.IsMatch(text, "{{(keep ?local|nocommons)", RegexOptions.IgnoreCase))
                    potentialProblems.Add("• The file is tagged with {{keep local}} - do not delete the local file afterwards.");

                Invoke(new Action(delegate()
                {
                    ToggleWarningBox(potentialProblems.Count > 0);
                    lblWarningText.Text = String.Join("\n", potentialProblems.ToArray());
                }));

                // build new file description page
                string origUploader = iis[iis.Count - 1].Attributes["user"].Value;

                text = CopyToCommonsRegex.Replace(text, "");
                text = Regex.Replace(text, "== ?(Summary|Licensing:?) ?== *\n", "\n");
                text = Regex.Replace(text, @"\[\[:?", "[[:en:");
                text = Regex.Replace(text, @"\[\[:en:([^\|\]]+)\]\]", new MatchEvaluator(delegate(Match m)
                    {
                        string linktext = m.Groups[1].Value;
                        if (!(linktext.ToLower().StartsWith("category:")))
                            return "[[:en:" + linktext + "|" + linktext + "]]";
                        return "<!-- [[" + linktext + "]] -->";  // comment out categories
                    }));
                // this next one is redundant to the above BUT still needed for categories with sortkeys
                text = Regex.Replace(text, @"\[\[:en:(Category:[^\]]+\]\])", "<!-- [[$1 -->");
                text = Regex.Replace(text, "{{orphan image.*}}\n?", "", RegexOptions.IgnoreCase);

                string beforeSelfTagCheck = text;
                text = Regex.Replace(text, "{{PD-self.*}}", "{{PD-user|" + origUploader + "|en}}", RegexOptions.IgnoreCase);
                text = Regex.Replace(text, @"{{GFDL-self-with-disclaimers([^\}]*)}}", "{{GFDL-user-en-with-disclaimers|" + origUploader + "$1}}", RegexOptions.IgnoreCase);
                text = Regex.Replace(text, @"{{GFDL-self([^\}]*)}}", "{{GFDL-user|" + origUploader + "|en$1}}", RegexOptions.IgnoreCase);
                bool selfLicense = (text != beforeSelfTagCheck);

                text = text.Trim();

                if (!Regex.IsMatch(text, "{{Information", RegexOptions.IgnoreCase))
                    text = @"{{Information
|Description    = {{en|1=}}
|Date           = 
|Source         = {{own}} <!-- change this if not own work -->
|Author         = " + (selfLicense ? ("[[:en:User:" + iis[0].Attributes["user"].Value + "|]]") : "") + @"
|Permission     = 
|Other_versions = 
}}

" + text;

                text += "\n\n== {{Original upload log}} ==\n\nThis file was originally uploaded at en.wikipedia as [http://en.wikipedia.org/wiki/" +
                    filename.Replace(" ", "_") + " " + filename + "], before it was transferred to Commons using [[:en:WP:FTCG|FtCG]].";

                text += "\n\n{| class=\"wikitable\"\n! Date/Time !! Dimensions !! User !! Comment";
                foreach (XmlNode n in iis)
                {
                    text += "\n|-\n| " + FormatTimestamp(n) + " || " + FormatDimensions(n);
                    text += " || {{uv|" + n.Attributes["user"].Value + "|w:en:}} || ''<nowiki>(" +
                        n.Attributes["comment"].Value + ")</nowiki>''";
                }
                text += "\n|}";

                Invoke(new Action(delegate()
                    {
                        textBox3.Text = text.Replace("\n", "\r\n");
                        lnkLocalFile.Enabled = true;
                        lnkCommonsFile.Enabled = false;
                    }));
            });
            sentry.Finally += new Action(delegate()
            {
                Invoke(new Action(delegate()
                {
                    EnableForm(true);
                }));
            });

            // download image file
            StringDictionary query = new StringDictionary 
            {
                { "action", "query" },
                { "prop", "imageinfo" },
                { "iiprop", "comment|timestamp|user|url|size|mime" },
                { "iilimit", "500" },
                { "iiurlwidth", pictureBox1.Width.ToString() },
                { "iiurlheight", pictureBox1.Height.ToString() },
                { "titles", filename },
                { "redirects", "true" }
            };
            MorebitsDotNet.PostApi(Wiki.EnWiki, query, delegate(XmlDocument doc)
            {
                switch (doc.GetElementsByTagName("page")[0].Attributes["imagerepository"].Value)
                {
                    case "shared":
                        MessageBox.Show("Image is already on Commons; can't do anything");
                        sentry.Fail();
                        return;
                    case "":
                        if (doc.GetElementsByTagName("page")[0].Attributes["missing"] != null)
                            MessageBox.Show("Image does not exist on enwiki");
                        else
                            MessageBox.Show("There seems to be a problem; perhaps the file is actually a redirect");
                        sentry.Fail();
                        return;
                }

                iis = doc.GetElementsByTagName("ii");

                Invoke(new Action(delegate()
                {
                    lblName.Text = doc.GetElementsByTagName("page")[0].Attributes["title"].Value;

                    if (iis.Count > 1)
                    {
                        lblPastRevisions.Visible = btnPastRevisions.Visible = true;
                        lblPastRevisions.Text = ((iis.Count == 2) ? "One earlier version" : (iis.Count - 1) + " earlier versions");
                    }
                    else
                        lblPastRevisions.Visible = btnPastRevisions.Visible = false;
                }));

                // download the file and display a thumbnail (also display metadata)
                DownloadFileAndDisplayThumb(iis[0]);

                sentry.DoneOne();
            }, ErrorHandler);

            // get wikitext of file description page
            query = new StringDictionary 
            {
                { "action", "query" },
                { "prop", "revisions" },
                { "rvprop", "content" },
                { "titles", filename },
                { "redirects", "true" }
            };
            MorebitsDotNet.PostApi(Wiki.EnWiki, query, delegate(XmlDocument doc)
            {
                if (doc.GetElementsByTagName("page")[0].Attributes["missing"] != null)
                {
                    // MessageBox.Show("Image does not exist on enwiki");    don't need to tell user twice
                    sentry.Fail();
                    return;
                }

                text = doc.GetElementsByTagName("rev")[0].InnerText;

                Invoke(new Action(delegate()
                {
                    textBox2.Text = text.Replace("\n", "\r\n");
                }));

                XmlNodeList ns = doc.GetElementsByTagName("n");
                if (ns.Count > 0)
                    Invoke(new Action(delegate()
                    {
                        filename = ns[0].Attributes["to"].Value;
                    }));
                Invoke(new Action(delegate()
                {
                    txtNormName.Text = filename;
                }));

                sentry.DoneOne();
            }, ErrorHandler);
        }

        WebClient cl;

        private void DownloadFileAndDisplayThumb(XmlNode n)
        {
            Invoke(new Action(delegate()
            {
                lblRevision.Text = (n.PreviousSibling == null ? "Current version (" : "Old version (") + FormatTimestamp(n) + ")";
                lblDimensions.Text = FormatDimensions(n);
                lblRevision.ForeColor = lblName.ForeColor = (n.PreviousSibling == null ? SystemColors.ControlText : Color.Red);

                pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
                pictureBox1.Image = pictureBox1.InitialImage;
            }));

            // decide whether PictureBox can display this image
            bool previewDownloadedFile = false;
            if (n.Attributes["thumburl"].Value == "")
            {
                // probably an OGG or something
                Invoke(new Action(delegate()
                {
                    pictureBox1.Image = pictureBox1.ErrorImage;
                }));
            }
            else
            {
                switch (n.Attributes["mime"].Value)
                {
                    // GDI+ natively supports only these formats
                    case "image/gif":
                    case "image/jpeg":
                    case "image/png":
                    case "image/tiff":
                        previewDownloadedFile = true;
                        break;
                    default:
                        // try to download PNG thumb
                        // ImageLocation doesn't work, because of the useragent
                        WebClient clThumb = new WebClient();
                        clThumb.Headers.Add("User-Agent", MorebitsDotNet.UserAgent);
                        clThumb.DownloadDataCompleted += new DownloadDataCompletedEventHandler(
                            delegate(object s, DownloadDataCompletedEventArgs v)
                            {
                                pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
                                Invoke(new Action(delegate()
                                {
                                    try
                                    {
                                        pictureBox1.Image = Image.FromStream(new MemoryStream(v.Result, false));
                                    }
                                    catch (Exception)
                                    {
                                        pictureBox1.Image = pictureBox1.ErrorImage;
                                    }
                                }));  // , true, true

                            });
                        clThumb.DownloadDataAsync(new Uri(n.Attributes["thumburl"].Value));
                        break;
                }
            }

            // download file
            cl = new WebClient();
            cl.Headers.Add("User-Agent", MorebitsDotNet.UserAgent);
            cl.DownloadDataCompleted += new DownloadDataCompletedEventHandler(
                delegate(object s, DownloadDataCompletedEventArgs v)
                {
                    if (v.Cancelled)
                        return;
                    if (v.Error != null)
                    {
                        MessageBox.Show("Failed to download the file. Perhaps try again later.\n\n" + v.Error.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    ImageData = v.Result;
                    if (previewDownloadedFile)
                    {
                        Invoke(new Action(delegate()
                        {
                            try
                            {
                                Image img = Image.FromStream(new MemoryStream(ImageData, false));
                                if (img.Height > pictureBox1.Height || img.Width > pictureBox1.Width)
                                    pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                                else
                                    pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
                                pictureBox1.Image = img;
                            }
                            catch (Exception)
                            {
                                pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
                                pictureBox1.Image = pictureBox1.ErrorImage;
                            }
                        }));  // , true, true
                    }
                });
            cl.DownloadDataAsync(new Uri(n.Attributes["url"].Value));
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
                button1_Click(sender, e);
        }

        // Random File feature
        // ===================

        List<string> RandomImageCache = new List<string>(500);
        Random rand = new Random();
        string RandomContinue;
        List<int> RandomBlacklist = new List<int>();  // to avoid weird infinite loops and other silliness

        private void RandomImage(object sender, EventArgs e)
        {
            if (RandomFileSource == FileSources.TextFile)
            {
                if (TextFileCache.Count == 0)
                {
                    try
                    {
                        TextFileCache.AddRange(File.ReadAllLines(SourceTag));
                    }
                    catch (Exception x)
                    {
                        ErrorHandler("Could not read the text file \"" + SourceTag + "\". Click the \"Other source...\" option to choose a different file.\n\n" + x.Message);
                        return;
                    }
                    TextFileCache.RemoveAll(str => String.IsNullOrEmpty(str));
                }
                RandomImageTextFileCore();
            }
            else if (RandomFileSource == FileSources.Category)
            {
                if (RandomImageCache.Count == 0)
                {
                    //string cat;
                    //if (optCopyBot.Checked)
                    //    cat = "Category:Copy to Wikimedia Commons (bot-assessed)";
                    //else if (optOther.Checked)
                    //    cat = optOther.Tag.ToString();
                    //else
                    //    cat = "Category:Copy to Wikimedia Commons";

                    StringDictionary query = new StringDictionary 
                    {
                        { "action", "query" },
                        { "list", "categorymembers" },
                        { "cmtitle", "Category:" + SourceTag },
                        { "cmnamespace", "6" },  // File:, obviously
                        { "cmsort", "timestamp" },
                        { "cmprop", "title" },
                        { "cmlimit", "500" },
                    };
                    if (RandomContinue != null)
                        query.Add("cmstart", RandomContinue);
                    MorebitsDotNet.PostApi(Wiki.EnWiki, query, delegate(XmlDocument doc)
                    {
                        foreach (XmlNode i in doc.GetElementsByTagName("cm"))
                            RandomImageCache.Add(i.Attributes["title"].Value);
                        if (RandomImageCache.Count == 0)
                        {
                            MessageBox.Show("That category contains no more files. Perhaps you misspelt it... or perhaps the backlog is finally clear :)");
                            return;
                        }

                        XmlNodeList continues = doc.GetElementsByTagName("query-continue");
                        if (continues.Count > 0)
                            RandomContinue = continues[0].FirstChild.Attributes["cmstart"].Value;
                        else
                            RandomContinue = null;

                        RandomImageCategoryCore();
                    }, ErrorHandler);
                }
                else
                    RandomImageCategoryCore();
            }
            else
            {
                throw new Exception("Internal error: the RandomFileSource is invalid.");
            }
        }

        private void RandomImageCategoryCore()
        {
            if (RandomBlacklist.Count >= RandomImageCache.Count)
            {
                MessageBox.Show("No more files in the random cache. Click \"Random file\" again to find more files.\n\n(This cannot be done automatically due to the possibility of never-ending loops.)\n\nDo not transfer the file that is currently displayed.");
                RandomImageCache.Clear();
                return;
            }

            int randIndex;
            do
            {
                randIndex = rand.Next(RandomImageCache.Count);
            } while (RandomBlacklist.Contains(randIndex));
            Invoke(new Action(delegate()
            {
                textBox1.Text = RandomImageCache[randIndex];
            }));
            RandomImageCache.RemoveAt(randIndex);

            CurrentFileSource = FileSources.Category;
            RandomCurrentIndex = randIndex;
            try
            {
                DownloadAndProcess();
            }
            finally
            {
                EnableForm(true);
            }
        }

        private void RandomImageTextFileCore()
        {
            // not really random - works through the file sequentially
            Invoke(new Action(delegate()
            {
                textBox1.Text = TextFileCache[0];
            }));
            TextFileCache.RemoveAt(0);

            CurrentFileSource = FileSources.TextFile;
            RandomCurrentIndex = 0;
            try
            {
                DownloadAndProcess();
            }
            finally
            {
                EnableForm(true);
            }
        }

        private void optCopyFoo_CheckedChanged(object sender, EventArgs e)
        {
            RandomImageCache.Clear();
            RandomContinue = null;
            RandomBlacklist = new List<int>();

            if (optCopy.Checked)
            {
                RandomFileSource = FileSources.Category;
                Settings.CurrentSourceOption = "Copy";
                SourceTag = "Copy to Wikimedia Commons";
            }
            else if (optCopyBot.Checked)
            {
                RandomFileSource = FileSources.Category;
                Settings.CurrentSourceOption = "CopyBot";
                SourceTag = "Copy to Wikimedia Commons (bot-assessed)";
            }
            else
            {
                // do nothing - other is handled elsewhere
            }

            button4.Text = RandomFileSource == FileSources.TextFile ? "Next file from list" : "Random file";
        }

        // Source selection
        // ================

        private void optOther_CheckedChanged(object sender, EventArgs e)
        {
            if (!optOther.Checked)
                return;

            frmRandomSource form = new frmRandomSource();
            if (!String.IsNullOrEmpty(Settings.SourceTextFile))
            {
                form.optTextFile.Checked = true;
                form.txtFileName.Text = Settings.SourceTextFile;
            }
            else if (!String.IsNullOrEmpty(Settings.SourceCategory))
                form.txtCategory.Text = Settings.SourceCategory;

            if (form.ShowDialog(this) == DialogResult.Cancel)
            {
                optCopy.Checked = true;
                RandomFileSource = FileSources.Category;
                Settings.CurrentSourceOption = "Copy";
                SourceTag = "Copy to Wikimedia Commons";
                return;
            }

            if (form.optTextFile.Checked)
            {
                RandomFileSource = FileSources.TextFile;
                Settings.CurrentSourceOption = "TextFile";
                SourceTag = Settings.SourceTextFile = form.txtFileName.Text;
                Settings.SourceCategory = "";
                TextFileCache.Clear();
            }
            else
            {
                RandomFileSource = FileSources.Category;
                Settings.CurrentSourceOption = "Category";
                SourceTag = Settings.SourceCategory = form.txtCategory.Text.Substring(
                    form.txtCategory.Text.ToLower().StartsWith("category:") ? "category:".Length : 0);
                Settings.SourceTextFile = "";
                RandomImageCache.Clear();
            }

            Settings.WriteSettings();
            button4.Text = RandomFileSource == FileSources.TextFile ? "Next file from list" : "Random file";
        }

        // Transfer to Commons
        // ===================

        private void DoTransfer(object sender, EventArgs e)
        {
            if (panWarning.Visible && MessageBox.Show("This file has potential problems which may prevent or affect the transfer. Do you still want to transfer this file to Commons?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                return;

            if (ImageData == null)
            {
                MessageBox.Show("The file hasn't been downloaded yet. Try again in a few moments.");
                return;
            }

            if (lblRevision.ForeColor == Color.Red && MessageBox.Show("You are transferring an old version of this file. You will need to manually clean up the \"original upload log\" section of the new wikitext. Click Cancel and do this (or click OK if you have already done so).", Application.ProductName, MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.Cancel)
                return;

            EnableForm(false);

            Action action = delegate()
            {

                StringDictionary query = new StringDictionary 
            {
                { "action", "query" },
                { "prop", "info" },
                { "intoken", "edit" },
                { "titles", txtNormName.Text }
            };
                MorebitsDotNet.PostApi(Wiki.Commons, query, delegate(XmlDocument doc)
                {
                    if (doc.GetElementsByTagName("page")[0].Attributes["missing"] == null && !chkIgnoreWarnings.Checked)
                    {
                        MessageBox.Show("An image of that name already exists on Commons.");
                        EnableForm(true);
                        return;
                    }

                    string newFilename = Regex.Replace(txtNormName.Text, "^(Image|File):", "");
                    string token = doc.GetElementsByTagName("page")[0].Attributes["edittoken"].Value;

                    StringDictionary uploadQuery = new StringDictionary 
                    {
                        { "action", "upload" },
                        { "filename", newFilename },
                        { "text", textBox3.Text.Replace("<!-- change this if not own work -->", "") },
                        { "comment", "Transferred from en.wikipedia: see original upload log above" },
                        { "token", token }
                    };
                    if (chkIgnoreWarnings.Checked)
                        uploadQuery.Add("ignorewarnings", "true");
                    MorebitsDotNet.UploadFile(Wiki.Commons, uploadQuery, ImageData, newFilename, "file", delegate(XmlDocument innerDoc)
                    {
                        // assuming success...

                        Invoke(new Action(delegate()
                        {
                            lnkCommonsFile.Enabled = true;
                            lnkCommonsFile.Tag = txtNormName.Text;
                        }));

                        XmlNodeList warnings = innerDoc.GetElementsByTagName("warnings");
                        if (warnings.Count > 0)
                        {
                            MessageBox.Show("The following warnings were encountered:\n\n" + warnings[0].OuterXml + "\n\nIf you still want to upload, select the \"Ignore warnings\" option and try again.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            EnableForm(true);
                            return;
                        }

                        // log the transfer, if requested
                        if (Settings.LogTransfers)
                        {
                            File.AppendAllText("CommonsTransfers.log", "# " +
                                DateTime.UtcNow.ToString("HH:mm, d MMMM yyyy", System.Globalization.DateTimeFormatInfo.InvariantInfo) +
                                " (UTC): [[:" + filename + "]] → [[:" + txtNormName.Text + "]]\r\n", Encoding.UTF8);
                        }

                        // finished?
                        if (!chkDeleteAfter.Checked)
                        {
                            if (Settings.OpenBrowserAutomatically)
                                lnkCommonsFile_LinkClicked(null, null);
                            else
                                MessageBox.Show("Successful.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            EnableForm(true);
                            return;
                        }

                        // continue with deleting/tagging with {{now Commons}}

                        Action innerAction = delegate()
                        {
                            if (Settings.LocalSysop)
                            {
                                DeleteLocal();
                                return;
                            }

                            StringDictionary enTokenQuery = new StringDictionary 
                            {
                                { "action", "query" },
                                { "prop", "info" },
                                { "intoken", "edit" },
                                { "titles", filename },  // old filename
                                { "redirects", "true" }
                            };
                            MorebitsDotNet.PostApi(Wiki.EnWiki, enTokenQuery, delegate(XmlDocument enDoc)
                            {
                                if (enDoc.GetElementsByTagName("page")[0].Attributes["missing"] != null)
                                {
                                    MessageBox.Show("The image seems to have been deleted on enwiki. Not sure what's going on.");
                                    EnableForm(true);
                                    return;
                                }

                                string enToken = enDoc.GetElementsByTagName("page")[0].Attributes["edittoken"].Value;

                                string enText = textBox2.Text;
                                string nowcommonsTag = "{{Now Commons|" + txtNormName.Text + "|date=" + DateTime.UtcNow.ToString("yyyy-MM-dd", DateTimeFormatInfo.InvariantInfo) + "}}";
                                string newText = CopyToCommonsRegex.Replace(enText, nowcommonsTag);
                                bool replaced = false;
                                if (enText == newText)
                                {
                                    newText = nowcommonsTag + newText;
                                    replaced = true;
                                }

                                StringDictionary enEditQuery = new StringDictionary 
                                {
                                    { "action", "edit" },
                                    { "token", enToken },
                                    { "title", filename },
                                    { "text", newText },
                                    { "summary", replaced ? "Replaced {{move to Commons}} tag with {{now Commons}} tag ([[WP:FTCG|FtCG]])" : "Added {{now Commons}} tag ([[WP:FTCG|FtCG]])" },
                                    { "nocreate", "true" },
                                    { "redirects", "true" }
                                };
                                MorebitsDotNet.PostApi(Wiki.EnWiki, enEditQuery, delegate(XmlDocument enInnerDoc)
                                {
                                    EnableForm(true);
                                    string editResult = enInnerDoc.GetElementsByTagName("edit")[0].Attributes["result"].Value.ToLower();
                                    if (editResult != "success")
                                    {
                                        MessageBox.Show("Successful up to the point of tagging the enwiki file with {{now commons}}: " + editResult, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        return;
                                    }
                                    if (Settings.OpenBrowserAutomatically)
                                        lnkCommonsFile_LinkClicked(null, null);
                                    else
                                        MessageBox.Show("Successful.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }, ErrorHandler);
                            }, ErrorHandler);
                        };

                        if (!MorebitsDotNet.LoginSessions[Wiki.EnWiki].LoggedIn)
                            MorebitsDotNet.LogIn(Wiki.EnWiki, Settings.LocalUserName,
                                Settings.LocalPassword, innerAction, ErrorHandler);
                        else
                            innerAction();
                    }, ErrorHandler);
                }, ErrorHandler);
            };

            if (!MorebitsDotNet.LoginSessions[Wiki.Commons].LoggedIn)
                MorebitsDotNet.LogIn(Wiki.Commons, Settings.CommonsUserName, Settings.CommonsPassword,
                    action, ErrorHandler);
            else
                action();
        }

        private void DeleteLocal()
        {
            EnableForm(false);

            Action action = delegate()
            {
                StringDictionary query = new StringDictionary 
                {
                    { "action", "query" },
                    { "prop", "info" },
                    { "intoken", "delete" },
                    { "titles", filename },
                    { "redirects", "true" }
                };
                MorebitsDotNet.PostApi(Wiki.EnWiki, query, delegate(XmlDocument doc)
                {
                    if (doc.GetElementsByTagName("page")[0].Attributes["missing"] != null)
                    {
                        MessageBox.Show("It looks like the image may have already been deleted.");
                        EnableForm(true);
                        return;
                    }

                    string token = doc.GetElementsByTagName("page")[0].Attributes["deletetoken"].Value;
                    StringDictionary deleteQuery = new StringDictionary 
                    {
                        { "action", "delete" },
                        { "reason", "[[WP:CSD#F8|F8]]: Media file available on Commons: [[" + lnkCommonsFile.Tag.ToString() + "]]" },
                        { "token", token },
                        { "title", filename },
                        { "redirects", "true" }
                    };
                    MorebitsDotNet.PostApi(Wiki.EnWiki, query, delegate(XmlDocument innerDoc)
                    {
                        EnableForm(true);
                        MessageBox.Show("Looks good to me.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }, ErrorHandler);
                }, ErrorHandler);
            };

            if (!MorebitsDotNet.LoginSessions[Wiki.EnWiki].LoggedIn)
                MorebitsDotNet.LogIn(Wiki.EnWiki, Settings.LocalUserName, Settings.LocalPassword,
                    action, ErrorHandler);
            else
                action();
        }

        private void DeclineTransfer(object sender, EventArgs e)
        {
            Action action = delegate()
            {
                string summary = frmPrompt.Prompt("Enter a reason for declining the Commons transfer request.\nThe {{copy to Commons}} tag will be automatically removed.");
                if (summary == null)
                    return;

                EnableForm(false);

                StringDictionary enTokenQuery = new StringDictionary 
                {
                    { "action", "query" },
                    { "prop", "info" },
                    { "intoken", "edit" },
                    { "titles", filename }  // old filename
                };
                MorebitsDotNet.PostApi(Wiki.EnWiki, enTokenQuery, delegate(XmlDocument enDoc)
                {
                    if (enDoc.GetElementsByTagName("page")[0].Attributes["missing"] != null)
                    {
                        MessageBox.Show("The image seems to have been deleted on enwiki. Not sure what's going on.");
                        EnableForm(true);
                        return;
                    }

                    string enToken = enDoc.GetElementsByTagName("page")[0].Attributes["edittoken"].Value;

                    string enText = textBox2.Text;
                    string newText = CopyToCommonsRegex.Replace(enText, "");
                    if (enText == newText)
                    {
                        MessageBox.Show("Could not find the {{copy to Commons}} tag to remove. Perhaps an obscure redirect is being used.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        EnableForm(true);
                        return;
                    }

                    StringDictionary enEditQuery = new StringDictionary 
                    {
                        { "action", "edit" },
                        { "token", enToken },
                        { "title", filename },
                        { "text", newText },
                        { "summary", "Declining {{Copy to Commons}} request: " + summary + " ([[WP:FTCG|FtCG]])" },
                        { "nocreate", "true" }
                    };
                    MorebitsDotNet.PostApi(Wiki.EnWiki, enEditQuery, delegate(XmlDocument enInnerDoc)
                    {
                        EnableForm(true);
                        string editResult = enInnerDoc.GetElementsByTagName("edit")[0].Attributes["result"].Value.ToLower();
                        MessageBox.Show(editResult == "success" ? "Successful." : "Failed: " + editResult, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }, ErrorHandler);
                }, ErrorHandler);
            };

            if (!MorebitsDotNet.LoginSessions[Wiki.EnWiki].LoggedIn)
                MorebitsDotNet.LogIn(Wiki.EnWiki, Settings.LocalUserName, Settings.LocalPassword,
                    action, ErrorHandler);
            else
                action();
        }

        // Misc. UI backing code
        // =====================

        private void btnSettings_Click(object sender, EventArgs e)
        {
            frmSettings set = new frmSettings();
            if (set.ShowDialog(this) == DialogResult.Cancel)
                return;
            foreach (Wiki w in MorebitsDotNet.LoginSessions.Keys)
                MorebitsDotNet.LoginSessions[w].LoggedIn = false;

            InitSettings();
        }

        void InitSettings()
        {
            switch (Settings.CurrentSourceOption.ToLower())
            {
                case "copybot":
                    optCopyBot.Checked = true;
                    RandomFileSource = FileSources.Category;
                    SourceTag = "Copy to Wikimedia Commons (bot-assessed)";
                    break;
                case "copy":
                default:
                    optCopy.Checked = true;
                    RandomFileSource = FileSources.Category;
                    SourceTag = "Copy to Wikimedia Commons";
                    break;
            }

            chkDeleteAfter.Text = Settings.LocalSysop ? "Delete local file after transfer" : "Tag local file with {{now Commons}}";
        }

        private void lnkLocalFile_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                Process.Start("https://en.wikipedia.org/wiki/" + filename);
            }
            catch (Exception)
            {
                MessageBox.Show("Can't open this link - you need to run FtCG locally, not in a Partial Trust scenario.");
            }
        }

        private void lnkCommonsFile_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                Process.Start("https://commons.wikimedia.org/wiki/" + lnkCommonsFile.Tag.ToString());
            }
            catch (Exception)
            {
                MessageBox.Show("Can't open this link - you need to run FtCG locally, not in a Partial Trust scenario.");
            }
        }

        private void SelectVersion(object sender, EventArgs e)
        {
            frmRevisionBrowse form = new frmRevisionBrowse();
            bool first = true;

            foreach (XmlNode i in iis)
            {
                ListViewItem item = new ListViewItem(new string[] {
                    "", 
                    (first ? "Current version\n" : "") + FormatTimestamp(i),
                    FormatDimensions(i),
                    i.Attributes["user"].Value,
                    i.Attributes["comment"].Value
                });
                item.Tag = i;

                TextureBrush checker = new TextureBrush(Properties.Resources.Checker_16x16, System.Drawing.Drawing2D.WrapMode.Tile);

                // download thumbnail
                WebClient cl = new WebClient();
                cl.Headers.Add("User-Agent", MorebitsDotNet.UserAgent);
                cl.DownloadDataCompleted += new DownloadDataCompletedEventHandler(
                    delegate(object s, DownloadDataCompletedEventArgs v)
                    {
                        byte[] data = v.Result;
                        Invoke(new Action(delegate()
                        {
                            Image original = Image.FromStream(new MemoryStream(data, false));
                            Bitmap img = new Bitmap(150, 150, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
                            using (Graphics g = Graphics.FromImage(img))
                            {
                                g.FillRectangle(checker, 0, 0, img.Width, img.Height);
                                if (original.Width > original.Height)
                                {
                                    float newHeight = ((float) original.Height) / ((float) original.Width / 150);
                                    g.DrawImage(original, 0f, (150f - newHeight) / 2f, 150f, newHeight);
                                }
                                else
                                {
                                    float newWidth = ((float) original.Width) / ((float) original.Height / 150f);
                                    g.DrawImage(original, (150f - newWidth) / 2f, 0f, newWidth, 150f);
                                }
                            }
                            lock (form)
                            {
                                form.imageList.Images.Add(img);
                                item.ImageIndex = form.imageList.Images.Count - 1;
                            }
                        }));
                    });
                cl.DownloadDataAsync(new Uri(i.Attributes["thumburl"].Value));

                if (first)
                {
                    item.UseItemStyleForSubItems = false;
                    item.SubItems[1].Font = new Font(item.Font, FontStyle.Bold);
                }
                form.listView.Items.Add(item);

                first = false;
            }

            if (form.ShowDialog() == DialogResult.Cancel)
                return;

            if (form.listView.SelectedItems.Count != 1)
            {
                MessageBox.Show("Now, go back and select one, and only one, item, you mischievous little child.");
                return;
            }

            ImageData = null;
            DownloadFileAndDisplayThumb((XmlNode) form.listView.SelectedItems[0].Tag);
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void frmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (optCopy.Checked)
            {
                Settings.CurrentSourceOption = "Copy";
            }
            else if (optCopyBot.Checked)
            {
                Settings.CurrentSourceOption = "CopyBot";
            }
            else if (RandomFileSource == FileSources.Category)
            {
                Settings.CurrentSourceOption = "Category";
            }
            else if (RandomFileSource == FileSources.TextFile)
            {
                Settings.CurrentSourceOption = "TextFile";
            }
            else
            {
                throw new Exception("invalid source");
            }
            Settings.WriteSettings();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (RandomFileSource == FileSources.TextFile)
            {
                switch (MessageBox.Show("For the Common Good can remove entries from the text file, up to the most recently processed entry.\n\nDo you want to save these changes to \"" +
                    Path.GetFileName(SourceTag) + "\"?", Application.ProductName, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question))
                {
                    case DialogResult.Yes:
                        try
                        {
                            File.WriteAllLines(SourceTag, TextFileCache.ToArray());
                        }
                        catch (Exception x)
                        {
                            ErrorHandler("Failed to save text file.\n\n" + x.Message);
                            e.Cancel = true;
                            return;
                        }
                        break;
                    case DialogResult.Cancel:
                        e.Cancel = true;
                        break;
                }
            }
        }
    }
}
